# ESP32 Playground — backend bundle

    npm install && npm run build
    node dist/server.js        # http://127.0.0.1:8760  (/api/health)

Set `ESPPLAY_QEMU` / `ESPPLAY_QEMU_RISCV` to the binaries from the qemu
bundle (default: work/espressif-qemu/build/qemu-system-xtensa in the repo).
