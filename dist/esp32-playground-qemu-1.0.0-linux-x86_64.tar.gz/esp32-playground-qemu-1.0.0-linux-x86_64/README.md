# ESP32 Playground — QEMU bundle (linux-x86_64)

Patched Espressif QEMU (esp32 + riscv32 targets) with the `espplay`
virtual-hardware family (GPIO/LEDC/RMT, UART, I2C, WiFi, BLE).

* `qemu-system-xtensa` — ESP32 machine
* `qemu-system-riscv32` — ESP32-C3 machine
* `start.sh` — standalone launcher (see script header for usage)

Normally these binaries are driven by the Node backend from
`esp32-playground-backend-*.tar.gz`. Build reproducibility: see
`scripts/build-qemu.sh` in the source repository (QEMU fork + patch
`qemu-patches/espressif-qemu-espplay.patch`).
