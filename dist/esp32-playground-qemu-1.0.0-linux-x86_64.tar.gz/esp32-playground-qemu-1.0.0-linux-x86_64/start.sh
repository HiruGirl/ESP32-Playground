#!/usr/bin/env bash
# Launch ESP32 Playground QEMU standalone (without the Node backend).
#   FIRMWARE=path/to/firmware.bin [PORT=5555] [ELF=path/to/firmware.elf] ./start.sh
# Then connect a bridge client to 127.0.0.1:$PORT (chardev socket protocol).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${FIRMWARE:?set FIRMWARE=/path/to/firmware.bin}"
PORT="${PORT:-5555}"
ELF_ARG=()
[ -n "${ELF:-}" ] && ELF_ARG=(",elf=$ELF")
exec "$HERE/qemu-system-xtensa" \
  -machine esp32 -display none -serial none \
  -drive "file=$FIRMWARE,if=mtd,format=raw" \
  -icount 10 \
  -chardev "socket,id=espsock,host=127.0.0.1,port=$PORT,server=on,wait=off" \
  -netdev user,id=net0 \
  -device "espplay.bridge,chardev=espsock,netdev=net0,cave-addr=0x400A0000${ELF_ARG[*]}"
